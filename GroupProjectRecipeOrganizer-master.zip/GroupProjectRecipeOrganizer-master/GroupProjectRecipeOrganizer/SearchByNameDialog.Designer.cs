﻿namespace GroupProjectRecipeOrganizer
{
    partial class SearchByNameDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtSearchRecipeName = new TextBox();
            btnSearchByNameClick = new Button();
            btnCloseSearchByName = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(134, 114);
            label1.Name = "label1";
            label1.Size = new Size(288, 38);
            label1.TabIndex = 0;
            label1.Text = "Enter a Recipe Name:";
            // 
            // txtSearchRecipeName
            // 
            txtSearchRecipeName.Location = new Point(439, 125);
            txtSearchRecipeName.Name = "txtSearchRecipeName";
            txtSearchRecipeName.Size = new Size(125, 27);
            txtSearchRecipeName.TabIndex = 1;
            // 
            // btnSearchByNameClick
            // 
            btnSearchByNameClick.Location = new Point(325, 255);
            btnSearchByNameClick.Name = "btnSearchByNameClick";
            btnSearchByNameClick.Size = new Size(128, 29);
            btnSearchByNameClick.TabIndex = 2;
            btnSearchByNameClick.Text = "Search By Name";
            btnSearchByNameClick.UseVisualStyleBackColor = true;
            btnSearchByNameClick.Click += btnSearchByNameClick_Click;
            // 
            // btnCloseSearchByName
            // 
            btnCloseSearchByName.Location = new Point(345, 379);
            btnCloseSearchByName.Name = "btnCloseSearchByName";
            btnCloseSearchByName.Size = new Size(94, 29);
            btnCloseSearchByName.TabIndex = 3;
            btnCloseSearchByName.Text = "Close";
            btnCloseSearchByName.UseVisualStyleBackColor = true;
            btnCloseSearchByName.Click += btnCloseSearchByName_Click;
            // 
            // SearchByNameDialog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCloseSearchByName);
            Controls.Add(btnSearchByNameClick);
            Controls.Add(txtSearchRecipeName);
            Controls.Add(label1);
            Name = "SearchByNameDialog";
            Text = "SearchByNameDialog";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtSearchRecipeName;
        private Button btnSearchByNameClick;
        private Button btnCloseSearchByName;
    }
}