﻿namespace GroupProjectRecipeOrganizer
{
    partial class FavouritesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            btnCloseFavourites = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 20;
            listBox1.Location = new Point(190, 80);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(433, 264);
            listBox1.TabIndex = 0;
            // 
            // btnCloseFavourites
            // 
            btnCloseFavourites.Location = new Point(354, 391);
            btnCloseFavourites.Name = "btnCloseFavourites";
            btnCloseFavourites.Size = new Size(94, 29);
            btnCloseFavourites.TabIndex = 1;
            btnCloseFavourites.Text = "Close";
            btnCloseFavourites.UseVisualStyleBackColor = true;
            btnCloseFavourites.Click += btnCloseFavourites_Click;
            // 
            // FavouritesForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCloseFavourites);
            Controls.Add(listBox1);
            Name = "FavouritesForm";
            Text = "FavouritesForm";
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBox1;
        private Button btnCloseFavourites;
    }
}