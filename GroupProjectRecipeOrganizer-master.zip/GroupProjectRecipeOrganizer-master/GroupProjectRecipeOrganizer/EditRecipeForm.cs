﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GroupProjectRecipeOrganizer
{
    public partial class EditRecipeForm : Form
    {
        private Recipe _selectedRecipe;
        private List<Ingredient> _ingredients;
        public EditRecipeForm(ref Recipe selectedRecipe, List<Ingredient> ingredients)
        {
            InitializeComponent();
            _selectedRecipe = selectedRecipe;
            _ingredients = ingredients ?? throw new ArgumentNullException(nameof(ingredients), "Ingredients list cannot be null.");
            PopulateFields();
            PopulateIngredientsComboBox();


            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        //private void PopulateIngredientsList(List<Ingredient> ingredients)
        //{
        //    // Populate list box with ingredients of the recipe
        //    foreach (Ingredient ingredient in ingredients)
        //    {
        //        lstIngredients.Items.Add(ingredient.IngredientName);
        //    }
        //}


        private void PopulateIngredientsComboBox()
        {
            // Clear the ComboBox
            cmbIngredients.Items.Clear();
            // Add Ingredients from the Ingredients list
            foreach (Ingredient ingredient in Ingredient.Ingredients)
            {
                cmbIngredients.Items.Add(ingredient.IngredientName);
            }
        }



        private void PopulateFields()
        {
            // Populate text boxes with recipe details
            txtName.Text = _selectedRecipe.Name;
            txtDescription.Text = _selectedRecipe.Description;
            cmbCategory.DataSource = Enum.GetValues(typeof(RecipeCategory));
            cmbCategory.SelectedItem = _selectedRecipe.Category;
            txtPreparation.Text = _selectedRecipe.Preparation;
            txtQuantity.Text = _selectedRecipe.quantity.ToString();


            // Populate list box with ingredients of the recipe
            foreach (Ingredient ingredient in _selectedRecipe.Ingredients)
            {
                lstIngredients.Items.Add(ingredient.IngredientName);
            }

        }


        private void btnAddIngredient_Click(object sender, EventArgs e)
        {
            string selectedIngredient = cmbIngredients.SelectedItem.ToString();
            if (!string.IsNullOrEmpty(selectedIngredient))
            {
                lstIngredients.Items.Add(selectedIngredient);
            }
        }

        private void btnRemoveIngredient_Click(object sender, EventArgs e)
        {
            if (lstIngredients.SelectedIndex != -1)
            {
                lstIngredients.Items.RemoveAt(lstIngredients.SelectedIndex);
            }
        }



        private void btnSaveEdit_Click(object sender, EventArgs e)
        {
            // Update recipe details with values from text boxes
            _selectedRecipe.Name = txtName.Text;
            _selectedRecipe.Description = txtDescription.Text;
            _selectedRecipe.Category = (RecipeCategory)cmbCategory.SelectedItem;
            _selectedRecipe.Preparation = txtPreparation.Text;
            _selectedRecipe.quantity = int.Parse(txtQuantity.Text);

            // Clear existing ingredients and add the ones from the list box
            _selectedRecipe.Ingredients.Clear();
            foreach (string ingredientName in lstIngredients.Items)
            {
                _selectedRecipe.Ingredients.Add(new Ingredient(ingredientName, 1)); // Default quantity is 1
            }

            DialogResult = DialogResult.Yes; // Indicate that changes were saved
            Close(); // Close the form
        }

        private void btnCancelEdit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel; // Indicate that changes were canceled
            Close(); // Close the form
        }
    }
}
