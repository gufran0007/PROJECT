﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProjectRecipeOrganizer
{
    public class Ingredient
    {


        public string IngredientName { get; set; }
        public double Quantity { get; set; }

        public Ingredient(string ingredientName, double quantity)
        {
            IngredientName = ingredientName;
            Quantity = quantity;
        }

        // Static method to get an ingredient by name
        public static Ingredient GetIngredientByName(string name, int quantity)
        {
            // Search for the ingredient with the given name in the predefined list
            foreach (Ingredient ingredient in Ingredients)
            {
                if (ingredient.IngredientName.Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    return ingredient;
                }   
            }
            // If not found, return a message
            return new Ingredient("Ingredient not found: " + name, quantity);
        }

        // Predefined list of ingredients
        public static List<Ingredient> Ingredients = new List<Ingredient>
        {
            new Ingredient("Pink Salt",1),
            new Ingredient("Pepper", 1),
            new Ingredient("Olive oil", 1),
            new Ingredient("Vegetable oil", 1),
            new Ingredient("All-purpose flour", 1),
            new Ingredient("Granulated sugar", 1),
            new Ingredient("Chicken stock or broth", 1),
            new Ingredient("Beef stock or broth", 1),
            new Ingredient("Canned tomatoes", 1),
            new Ingredient("Tomato sauce", 1),
            new Ingredient("Tomato paste", 1),
            new Ingredient("Can/jar of marinara sauce", 1),
            new Ingredient("Canned beans: white", 1),
            new Ingredient("Canned beans: black", 1),
            new Ingredient("Canned beans: kidney", 1),
            new Ingredient("Tuna", 1),
            new Ingredient("Pasta", 1),
            new Ingredient("Rice", 1),
            new Ingredient("Lentils", 1),
            new Ingredient("Split peas", 1),
            new Ingredient("Dried bread crumbs", 1),
            new Ingredient("Potatoes", 1),
            new Ingredient("Onions", 1),
            new Ingredient("Garlic", 1),
            new Ingredient("Eggs"   , 1),
            new Ingredient("Milk", 1),
            new Ingredient("Butter or margarine", 1),
            new Ingredient("Ketchup", 1),
            new Ingredient("Mustard (yellow, Dijon, whole grain)", 1),
            new Ingredient("Mayonnaise", 1),
            new Ingredient("Parmesan cheese", 1),
            new Ingredient("Other cheese", 1),
            new Ingredient("Carrots", 1),
            new Ingredient("Celery", 1),
            new Ingredient("Thyme", 1),
            new Ingredient("Rosemary", 1),
            new Ingredient("Bell Peppers", 1),
            new Ingredient("Mushrooms", 1),
            new Ingredient("Chicken", 1),
            new Ingredient("Beef", 1),
            new Ingredient("White Wine", 1),
            new Ingredient("Red Wine", 1),
            new Ingredient("Worcestershire Sauce", 1),
            new Ingredient("Paprika", 1),
            new Ingredient("Cumin",1 ),
            new Ingredient("Chili Powder", 1)
        };

    }
}
