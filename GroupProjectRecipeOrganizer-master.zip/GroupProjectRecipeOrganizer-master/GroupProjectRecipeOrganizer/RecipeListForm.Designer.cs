﻿namespace GroupProjectRecipeOrganizer
{
    partial class RecipeListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvRecipes = new DataGridView();
            btnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvRecipes).BeginInit();
            SuspendLayout();
            // 
            // dgvRecipes
            // 
            dgvRecipes.BackgroundColor = SystemColors.Window;
            dgvRecipes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRecipes.GridColor = SystemColors.ControlLightLight;
            dgvRecipes.Location = new Point(10, 9);
            dgvRecipes.Margin = new Padding(3, 2, 3, 2);
            dgvRecipes.Name = "dgvRecipes";
            dgvRecipes.RowHeadersWidth = 51;
            dgvRecipes.RowTemplate.Height = 29;
            dgvRecipes.Size = new Size(679, 275);
            dgvRecipes.TabIndex = 0;
            dgvRecipes.CellContentClick += dgvRecipes_CellContentClick;
            // 
            // btnClose
            // 
            btnClose.Location = new Point(302, 379);
            btnClose.Margin = new Padding(3, 2, 3, 2);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(82, 22);
            btnClose.TabIndex = 1;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // RecipeListForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 410);
            Controls.Add(btnClose);
            Controls.Add(dgvRecipes);
            Margin = new Padding(3, 2, 3, 2);
            Name = "RecipeListForm";
            Text = "RecipeListForm";
            Load += RecipeListForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvRecipes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvRecipes;
        private Button btnClose;
    }
}