﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class FavouritesForm : Form
    {
        private List<Recipe> favorites;
        public FavouritesForm(List<Recipe> favoriteRecipes)
        {
            InitializeComponent();
            favorites = favoriteRecipes;
            DisplayFavorites();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void DisplayFavorites()
        {
            listBox1.Items.Clear();
            foreach (Recipe recipe in favorites)
            {
                listBox1.Items.Add(recipe.Name);
            }
        }

        private void btnCloseFavourites_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
