﻿namespace GroupProjectRecipeOrganizer
{
    partial class RecipeOrganizer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnCREATE = new Button();
            btnRecipes = new Button();
            btnSearch = new Button();
            btnExit = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(216, 40);
            label1.Name = "label1";
            label1.Size = new Size(319, 50);
            label1.TabIndex = 0;
            label1.Text = "Recipe Organizer";
            // 
            // btnCREATE
            // 
            btnCREATE.Location = new Point(319, 123);
            btnCREATE.Name = "btnCREATE";
            btnCREATE.Size = new Size(118, 32);
            btnCREATE.TabIndex = 1;
            btnCREATE.Text = "Create Recipe";
            btnCREATE.UseVisualStyleBackColor = true;
            btnCREATE.Click += btnCREATE_Click;
            // 
            // btnRecipes
            // 
            btnRecipes.Location = new Point(319, 181);
            btnRecipes.Name = "btnRecipes";
            btnRecipes.Size = new Size(118, 32);
            btnRecipes.TabIndex = 2;
            btnRecipes.Text = "Recipes";
            btnRecipes.UseVisualStyleBackColor = true;
            btnRecipes.Click += btnRecipes_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(319, 300);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(118, 31);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(329, 371);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(94, 29);
            btnExit.TabIndex = 4;
            btnExit.Text = "E&xit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // button1
            // 
            button1.Location = new Point(319, 241);
            button1.Name = "button1";
            button1.Size = new Size(118, 32);
            button1.TabIndex = 5;
            button1.Text = "Favourites";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // RecipeOrganizer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(800, 451);
            Controls.Add(button1);
            Controls.Add(btnExit);
            Controls.Add(btnSearch);
            Controls.Add(btnRecipes);
            Controls.Add(btnCREATE);
            Controls.Add(label1);
            Name = "RecipeOrganizer";
            Text = "RecipeOrganizer";
            Load += RecipeOrganizer_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnCREATE;
        private Button btnRecipes;
        private Button btnSearch;
        private Button btnExit;
        private Button button1;
    }
}