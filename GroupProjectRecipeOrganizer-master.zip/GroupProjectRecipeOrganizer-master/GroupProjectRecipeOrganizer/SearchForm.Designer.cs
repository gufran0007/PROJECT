﻿namespace GroupProjectRecipeOrganizer
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSearchByName = new Button();
            btnSearchByCategory = new Button();
            btnSearchByIngredient = new Button();
            btnSearchClose = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(310, 51);
            label1.Name = "label1";
            label1.Size = new Size(194, 50);
            label1.TabIndex = 0;
            label1.Text = "Search by:";
            // 
            // btnSearchByName
            // 
            btnSearchByName.Location = new Point(137, 187);
            btnSearchByName.Name = "btnSearchByName";
            btnSearchByName.Size = new Size(114, 29);
            btnSearchByName.TabIndex = 1;
            btnSearchByName.Text = "Recipe Name";
            btnSearchByName.UseVisualStyleBackColor = true;
            btnSearchByName.Click += btnSearchByName_Click;
            // 
            // btnSearchByCategory
            // 
            btnSearchByCategory.Location = new Point(345, 187);
            btnSearchByCategory.Name = "btnSearchByCategory";
            btnSearchByCategory.Size = new Size(114, 29);
            btnSearchByCategory.TabIndex = 2;
            btnSearchByCategory.Text = "Category";
            btnSearchByCategory.UseVisualStyleBackColor = true;
            btnSearchByCategory.Click += btnSearchByCategory_Click;
            // 
            // btnSearchByIngredient
            // 
            btnSearchByIngredient.Location = new Point(554, 187);
            btnSearchByIngredient.Name = "btnSearchByIngredient";
            btnSearchByIngredient.Size = new Size(114, 29);
            btnSearchByIngredient.TabIndex = 3;
            btnSearchByIngredient.Text = "Ingredient";
            btnSearchByIngredient.UseVisualStyleBackColor = true;
            btnSearchByIngredient.Click += btnSearchByIngredient_Click;
            // 
            // btnSearchClose
            // 
            btnSearchClose.Location = new Point(356, 396);
            btnSearchClose.Name = "btnSearchClose";
            btnSearchClose.Size = new Size(94, 29);
            btnSearchClose.TabIndex = 4;
            btnSearchClose.Text = "Close";
            btnSearchClose.UseVisualStyleBackColor = true;
            btnSearchClose.Click += btnSearchClose_Click;
            // 
            // SearchForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSearchClose);
            Controls.Add(btnSearchByIngredient);
            Controls.Add(btnSearchByCategory);
            Controls.Add(btnSearchByName);
            Controls.Add(label1);
            Name = "SearchForm";
            Text = "SearchForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSearchByName;
        private Button btnSearchByCategory;
        private Button btnSearchByIngredient;
        private Button btnSearchClose;
    }
}