﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class RecipeListForm : Form
    {
        public RecipeListForm()
        {
            InitializeComponent();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        //stuff
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RecipeListForm_Load(object sender, EventArgs e)
        {

        }

        private void dgvRecipes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
