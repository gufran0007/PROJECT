﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class SearchByIngredientDialog : Form
    {
        public List<Recipe> recipes;
        public SearchByIngredientDialog(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            PopulateComboBox();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }


        private void PopulateComboBox()
        {
            cmbIngredients.Items.Clear();

            // Add Ingredients from the Ingredients list
            foreach (Ingredient ingredient in Ingredient.Ingredients)
            {
                cmbIngredients.Items.Add(ingredient.IngredientName);
            }
        }

        private void btnSearchByIngredientClick_Click(object sender, EventArgs e)
        {
            string selectedIngredient = cmbIngredients.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedIngredient))
            {
                // Perform the search based on the selected ingredient
                List<Recipe> foundRecipes = SearchRecipesByIngredient(selectedIngredient);

                // Show the search results
                ShowSearchResults(foundRecipes);
            }
            else
            {
                MessageBox.Show("Please select an ingredient.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private List<Recipe> SearchRecipesByIngredient(string ingredientName)
        {
            // Filter recipes based on the specified ingredient
            return recipes.Where(r => r.Ingredients.Any(i => i.IngredientName.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))).ToList();
        }


        private void ShowSearchResults(List<Recipe> foundRecipes)
        {
            if (foundRecipes.Any())
            {
                StringBuilder message = new StringBuilder();
                message.AppendLine("Recipes found with the selected ingredient:");
                foreach (Recipe recipe in foundRecipes)
                {
                    message.AppendLine($"- {recipe.Name}");
                }
                MessageBox.Show(message.ToString(), "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No recipes found with the selected ingredient.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSearchByIngredientClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
