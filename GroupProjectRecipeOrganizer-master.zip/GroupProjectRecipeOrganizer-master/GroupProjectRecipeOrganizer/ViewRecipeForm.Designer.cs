﻿namespace GroupProjectRecipeOrganizer
{
    partial class ViewRecipeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvViewRecipeForm = new DataGridView();
            btnVRFClose = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvViewRecipeForm).BeginInit();
            SuspendLayout();
            // 
            // dgvViewRecipeForm
            // 
            dgvViewRecipeForm.BackgroundColor = SystemColors.Control;
            dgvViewRecipeForm.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvViewRecipeForm.Location = new Point(47, 58);
            dgvViewRecipeForm.Name = "dgvViewRecipeForm";
            dgvViewRecipeForm.RowHeadersWidth = 51;
            dgvViewRecipeForm.RowTemplate.Height = 29;
            dgvViewRecipeForm.Size = new Size(776, 345);
            dgvViewRecipeForm.TabIndex = 0;
            dgvViewRecipeForm.CellContentClick += dgvViewRecipeForm_CellContentClick;
            // 
            // btnVRFClose
            // 
            btnVRFClose.Location = new Point(383, 457);
            btnVRFClose.Name = "btnVRFClose";
            btnVRFClose.Size = new Size(94, 29);
            btnVRFClose.TabIndex = 1;
            btnVRFClose.Text = "Close";
            btnVRFClose.UseVisualStyleBackColor = true;
            btnVRFClose.Click += btnVRFClose_Click;
            // 
            // ViewRecipeForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(856, 498);
            Controls.Add(btnVRFClose);
            Controls.Add(dgvViewRecipeForm);
            Name = "ViewRecipeForm";
            Text = "ViewRecipeForm";
            ((System.ComponentModel.ISupportInitialize)dgvViewRecipeForm).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvViewRecipeForm;
        private Button btnVRFClose;
    }
}