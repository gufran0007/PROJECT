﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GroupProjectRecipeOrganizer
{
    public partial class CreateRecipeForm : Form
    {
        private List<Recipe> recipes;
        public CreateRecipeForm(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            cmbCategory.DataSource = Enum.GetValues(typeof(RecipeCategory));
            PopulateIngredientsComboBox();


            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }


        private void PopulateIngredientsComboBox()
        {
            // Clear the ComboBox
            cmbIngredient.Items.Clear();
            // Add Ingredients from the Ingredients list
            foreach (Ingredient ingredient in Ingredient.Ingredients)
            {
                cmbIngredient.Items.Add(ingredient.IngredientName);
            }
        }


        private void btnSaveCreate_Click(object sender, EventArgs e)
        {
            // Retrieve values from the form controls
            string name = txtName.Text;
            string description = txtDescription.Text;
            RecipeCategory category = (RecipeCategory)cmbCategory.SelectedItem;
            string preparation = txtPreparation.Text;
            int quantity = (int)numQuantity.Value;

            // Create a new list to store ingredients
            List<Ingredient> ingredients = new List<Ingredient>();

            // Add each ingredient from the ComboBox
            foreach (string ingredientName in lstIngredients.Items)
            {
                ingredients.Add(Ingredient.GetIngredientByName(ingredientName, 1)); // Default quantity is 1
            }

            // Create a new Recipe object
            Recipe newRecipe = new Recipe(name, description, category, ingredients, preparation, "", quantity, false);

            // Add the new recipe to the list of recipes
            recipes.Add(newRecipe);

            // Close the form
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancelCreate_Click(object sender, EventArgs e)
        {
            // Close the form without saving
            DialogResult = DialogResult.Cancel;
            Close();
        }


        private void btnAddIngredient_Click(object sender, EventArgs e)
        {
            // Get the ingredient from the text box
            string ingredientName = cmbIngredient.SelectedItem.ToString();

            // Add the ingredient to the list box
            if (!string.IsNullOrEmpty(ingredientName))
            {
                lstIngredients.Items.Add(ingredientName);
            }
        }



        private void btnRemoveIngredient_Click(object sender, EventArgs e)
        {
            // Check if an item is selected in the list box
            if (lstIngredients.SelectedIndex != -1)
            {
                // Remove the selected item from the list box
                lstIngredients.Items.RemoveAt(lstIngredients.SelectedIndex);
            }
        }

        private void CreateRecipeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
