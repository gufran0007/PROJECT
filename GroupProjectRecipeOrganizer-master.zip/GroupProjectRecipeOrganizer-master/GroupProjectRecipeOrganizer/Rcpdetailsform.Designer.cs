﻿namespace GroupProjectRecipeOrganizer
{
    partial class Rcpdetailsform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            Ingredients = new ListBox();
            label1 = new Label();
            Rate = new Button();
            ratings = new Button();
            addtofavourites = new Button();
            addnote = new Button();
            seenote = new Button();
            Scalerecipe = new Button();
            button1 = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            label11 = new Label();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(317, 149);
            label2.Name = "label2";
            label2.Size = new Size(85, 20);
            label2.TabIndex = 1;
            label2.Text = "Description";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(317, 201);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 2;
            label3.Text = "label3";
            label3.Click += label3_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(371, 327);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(317, 252);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(183, 27);
            textBox1.TabIndex = 5;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // Ingredients
            // 
            Ingredients.FormattingEnabled = true;
            Ingredients.ItemHeight = 20;
            Ingredients.Location = new Point(317, 312);
            Ingredients.Margin = new Padding(3, 4, 3, 4);
            Ingredients.Name = "Ingredients";
            Ingredients.Size = new Size(218, 84);
            Ingredients.TabIndex = 6;
            Ingredients.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(317, 97);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 7;
            label1.Text = "label1";
            label1.Click += label1_Click;
            // 
            // Rate
            // 
            Rate.Location = new Point(622, 57);
            Rate.Margin = new Padding(3, 4, 3, 4);
            Rate.Name = "Rate";
            Rate.Size = new Size(136, 31);
            Rate.TabIndex = 8;
            Rate.Text = "Rate Recipe";
            Rate.UseVisualStyleBackColor = true;
            Rate.Click += Rate_Click;
            // 
            // ratings
            // 
            ratings.Location = new Point(622, 112);
            ratings.Margin = new Padding(3, 4, 3, 4);
            ratings.Name = "ratings";
            ratings.Size = new Size(136, 31);
            ratings.TabIndex = 9;
            ratings.Text = "Ratings";
            ratings.UseVisualStyleBackColor = true;
            ratings.Click += ratings_Click;
            // 
            // addtofavourites
            // 
            addtofavourites.Location = new Point(622, 164);
            addtofavourites.Margin = new Padding(3, 4, 3, 4);
            addtofavourites.Name = "addtofavourites";
            addtofavourites.Size = new Size(144, 31);
            addtofavourites.TabIndex = 10;
            addtofavourites.Text = "Add to Favourites";
            addtofavourites.UseVisualStyleBackColor = true;
            addtofavourites.Click += addtofavourites_Click;
            // 
            // addnote
            // 
            addnote.Location = new Point(622, 229);
            addnote.Margin = new Padding(3, 4, 3, 4);
            addnote.Name = "addnote";
            addnote.Size = new Size(145, 31);
            addnote.TabIndex = 11;
            addnote.Text = "Add a note";
            addnote.UseVisualStyleBackColor = true;
            addnote.Click += addnote_Click;
            // 
            // seenote
            // 
            seenote.Location = new Point(622, 291);
            seenote.Margin = new Padding(3, 4, 3, 4);
            seenote.Name = "seenote";
            seenote.Size = new Size(154, 31);
            seenote.TabIndex = 12;
            seenote.Text = "See note";
            seenote.UseVisualStyleBackColor = true;
            seenote.Click += seenote_Click;
            // 
            // Scalerecipe
            // 
            Scalerecipe.Location = new Point(622, 351);
            Scalerecipe.Margin = new Padding(3, 4, 3, 4);
            Scalerecipe.Name = "Scalerecipe";
            Scalerecipe.Size = new Size(151, 31);
            Scalerecipe.TabIndex = 13;
            Scalerecipe.Text = "Scale Recipe";
            Scalerecipe.UseVisualStyleBackColor = true;
            Scalerecipe.Click += Scalerecipe_Click;
            // 
            // button1
            // 
            button1.Location = new Point(622, 405);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(151, 31);
            button1.TabIndex = 14;
            button1.Text = "Close";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(156, 140);
            label6.Name = "label6";
            label6.Size = new Size(134, 31);
            label6.TabIndex = 15;
            label6.Text = "Description";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(155, 192);
            label7.Name = "label7";
            label7.Size = new Size(110, 31);
            label7.TabIndex = 16;
            label7.Text = "Category";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(155, 88);
            label8.Name = "label8";
            label8.Size = new Size(76, 31);
            label8.TabIndex = 17;
            label8.Text = "Name";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(155, 247);
            label10.Name = "label10";
            label10.Size = new Size(136, 31);
            label10.TabIndex = 19;
            label10.Text = "Preparation";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(156, 303);
            label11.Name = "label11";
            label11.Size = new Size(132, 31);
            label11.TabIndex = 20;
            label11.Text = "Ingredients";
            // 
            // Rcpdetailsform
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(button1);
            Controls.Add(Scalerecipe);
            Controls.Add(seenote);
            Controls.Add(addnote);
            Controls.Add(addtofavourites);
            Controls.Add(ratings);
            Controls.Add(Rate);
            Controls.Add(label1);
            Controls.Add(Ingredients);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Rcpdetailsform";
            Text = "Rcpdetailsform";
            Load += Rcpdetailsform_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox1;
        private ListBox Ingredients;
        private Label label1;
        private Button Rate;
        private Button ratings;
        private Button addtofavourites;
        private Button addnote;
        private Button seenote;
        private Button Scalerecipe;
        private Button button1;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
    }
}