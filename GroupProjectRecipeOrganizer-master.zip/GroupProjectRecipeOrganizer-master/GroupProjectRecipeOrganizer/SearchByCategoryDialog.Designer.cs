﻿namespace GroupProjectRecipeOrganizer
{
    partial class SearchByCategoryDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSearchByCategoryClick = new Button();
            btnSearchCategoryClose = new Button();
            comboBoxCategories = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(129, 107);
            label1.Name = "label1";
            label1.Size = new Size(314, 38);
            label1.TabIndex = 0;
            label1.Text = "Select Recipe Category:";
            // 
            // btnSearchByCategoryClick
            // 
            btnSearchByCategoryClick.Location = new Point(317, 236);
            btnSearchByCategoryClick.Name = "btnSearchByCategoryClick";
            btnSearchByCategoryClick.Size = new Size(159, 29);
            btnSearchByCategoryClick.TabIndex = 2;
            btnSearchByCategoryClick.Text = "Search By Category";
            btnSearchByCategoryClick.UseVisualStyleBackColor = true;
            btnSearchByCategoryClick.Click += btnSearchByCategoryClick_Click;
            // 
            // btnSearchCategoryClose
            // 
            btnSearchCategoryClose.Location = new Point(349, 366);
            btnSearchCategoryClose.Name = "btnSearchCategoryClose";
            btnSearchCategoryClose.Size = new Size(94, 29);
            btnSearchCategoryClose.TabIndex = 3;
            btnSearchCategoryClose.Text = "Close";
            btnSearchCategoryClose.UseVisualStyleBackColor = true;
            btnSearchCategoryClose.Click += btnSearchCategoryClose_Click;
            // 
            // comboBoxCategories
            // 
            comboBoxCategories.FormattingEnabled = true;
            comboBoxCategories.Location = new Point(449, 117);
            comboBoxCategories.Name = "comboBoxCategories";
            comboBoxCategories.Size = new Size(151, 28);
            comboBoxCategories.TabIndex = 4;
            // 
            // SearchByCategoryDialog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(comboBoxCategories);
            Controls.Add(btnSearchCategoryClose);
            Controls.Add(btnSearchByCategoryClick);
            Controls.Add(label1);
            Name = "SearchByCategoryDialog";
            Text = "SearchByCategoryDialog";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSearchByCategoryClick;
        private Button btnSearchCategoryClose;
        private ComboBox comboBoxCategories;
    }
}