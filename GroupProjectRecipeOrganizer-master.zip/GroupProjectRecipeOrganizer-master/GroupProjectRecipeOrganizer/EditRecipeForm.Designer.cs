﻿namespace GroupProjectRecipeOrganizer
{
    partial class EditRecipeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtName = new TextBox();
            txtDescription = new TextBox();
            cmbCategory = new ComboBox();
            txtPreparation = new TextBox();
            txtQuantity = new TextBox();
            lstIngredients = new ListBox();
            btnSaveEdit = new Button();
            btnCancelEdit = new Button();
            label7 = new Label();
            cmbIngredients = new ComboBox();
            btnAddIngredient = new Button();
            btnRemoveIngredient = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(123, 55);
            label1.Name = "label1";
            label1.Size = new Size(150, 31);
            label1.TabIndex = 0;
            label1.Text = "Recipe Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(125, 93);
            label2.Name = "label2";
            label2.Size = new Size(134, 31);
            label2.TabIndex = 1;
            label2.Text = "Description";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(127, 135);
            label3.Name = "label3";
            label3.Size = new Size(110, 31);
            label3.TabIndex = 2;
            label3.Text = "Category";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(125, 174);
            label4.Name = "label4";
            label4.Size = new Size(136, 31);
            label4.TabIndex = 3;
            label4.Text = "Preparation";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(125, 210);
            label5.Name = "label5";
            label5.Size = new Size(103, 31);
            label5.TabIndex = 4;
            label5.Text = "Quantity";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(123, 257);
            label6.Name = "label6";
            label6.Size = new Size(132, 31);
            label6.TabIndex = 5;
            label6.Text = "Ingredients";
            // 
            // txtName
            // 
            txtName.Enabled = false;
            txtName.Location = new Point(348, 55);
            txtName.Name = "txtName";
            txtName.Size = new Size(125, 27);
            txtName.TabIndex = 6;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(348, 93);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(125, 27);
            txtDescription.TabIndex = 7;
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Location = new Point(348, 134);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(151, 28);
            cmbCategory.TabIndex = 8;
            // 
            // txtPreparation
            // 
            txtPreparation.Location = new Point(348, 174);
            txtPreparation.Name = "txtPreparation";
            txtPreparation.Size = new Size(125, 27);
            txtPreparation.TabIndex = 9;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(348, 210);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 27);
            txtQuantity.TabIndex = 10;
            // 
            // lstIngredients
            // 
            lstIngredients.FormattingEnabled = true;
            lstIngredients.ItemHeight = 20;
            lstIngredients.Location = new Point(348, 253);
            lstIngredients.Name = "lstIngredients";
            lstIngredients.Size = new Size(427, 104);
            lstIngredients.TabIndex = 12;
            // 
            // btnSaveEdit
            // 
            btnSaveEdit.Location = new Point(209, 510);
            btnSaveEdit.Name = "btnSaveEdit";
            btnSaveEdit.Size = new Size(94, 29);
            btnSaveEdit.TabIndex = 13;
            btnSaveEdit.Text = "Save";
            btnSaveEdit.UseVisualStyleBackColor = true;
            btnSaveEdit.Click += btnSaveEdit_Click;
            // 
            // btnCancelEdit
            // 
            btnCancelEdit.Location = new Point(492, 510);
            btnCancelEdit.Name = "btnCancelEdit";
            btnCancelEdit.Size = new Size(94, 29);
            btnCancelEdit.TabIndex = 14;
            btnCancelEdit.Text = "Cancel";
            btnCancelEdit.UseVisualStyleBackColor = true;
            btnCancelEdit.Click += btnCancelEdit_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(127, 396);
            label7.Name = "label7";
            label7.Size = new Size(122, 31);
            label7.TabIndex = 15;
            label7.Text = "Ingredient";
            // 
            // cmbIngredients
            // 
            cmbIngredients.FormattingEnabled = true;
            cmbIngredients.Location = new Point(348, 394);
            cmbIngredients.Name = "cmbIngredients";
            cmbIngredients.Size = new Size(151, 28);
            cmbIngredients.TabIndex = 16;
            // 
            // btnAddIngredient
            // 
            btnAddIngredient.Location = new Point(536, 394);
            btnAddIngredient.Name = "btnAddIngredient";
            btnAddIngredient.Size = new Size(94, 29);
            btnAddIngredient.TabIndex = 17;
            btnAddIngredient.Text = "Add";
            btnAddIngredient.UseVisualStyleBackColor = true;
            btnAddIngredient.Click += btnAddIngredient_Click;
            // 
            // btnRemoveIngredient
            // 
            btnRemoveIngredient.Location = new Point(666, 394);
            btnRemoveIngredient.Name = "btnRemoveIngredient";
            btnRemoveIngredient.Size = new Size(94, 29);
            btnRemoveIngredient.TabIndex = 18;
            btnRemoveIngredient.Text = "Remove";
            btnRemoveIngredient.UseVisualStyleBackColor = true;
            btnRemoveIngredient.Click += btnRemoveIngredient_Click;
            // 
            // EditRecipeForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 551);
            Controls.Add(btnRemoveIngredient);
            Controls.Add(btnAddIngredient);
            Controls.Add(cmbIngredients);
            Controls.Add(label7);
            Controls.Add(btnCancelEdit);
            Controls.Add(btnSaveEdit);
            Controls.Add(lstIngredients);
            Controls.Add(txtQuantity);
            Controls.Add(txtPreparation);
            Controls.Add(cmbCategory);
            Controls.Add(txtDescription);
            Controls.Add(txtName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditRecipeForm";
            Text = "EditRecipeForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtName;
        private TextBox txtDescription;
        private ComboBox cmbCategory;
        private TextBox txtPreparation;
        private TextBox txtQuantity;
        private ListBox lstIngredients;
        private Button btnSaveEdit;
        private Button btnCancelEdit;
        private Label label7;
        private ComboBox cmbIngredients;
        private Button btnAddIngredient;
        private Button btnRemoveIngredient;
    }
}