﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace GroupProjectRecipeOrganizer
    {
        public enum RecipeCategory
        {
            Breakfast,
            Lunch,
            Dinner,
            Dessert,
            Snack,
            Appetizer,
            Beverage,
            Salad,
            Soup,
            SideDish,
            MainCourse,
            Sauce,
            Bread,
            Pasta,
            Rice,
            Seafood,
            Vegetarian,
            Vegan,
            GlutenFree,
            DairyFree,
            NutFree,
            LowCarb,
            HighProtein,
            Other
        }

        public class Recipe
        {
            public string Name { get; set; }
            public string Description { get; set; }
            public RecipeCategory Category { get; set; }
            public List<Ingredient> Ingredients { get; set; }
            public string Preparation { get; set; }
            public string Notes { get; set; }
             public int quantity {  get; set; }
             public bool IsFavorite { get; set; }
        //original servings
             public int BaseServings { get; set; }


        // public string ImagePath { get; set; }
        private List<int> ratings = new List<int>();

        public Recipe(string name, string description, RecipeCategory category, List<Ingredient> ingredients, string preparation,string Notes,int Quantity,bool IsFavorite/*, string imagePath*/)
            {
                Name = name;
                Description = description;
                Category = category;
                Ingredients = ingredients;
                Preparation = preparation;
                Notes = Notes;
                quantity =Quantity;
                this.IsFavorite = IsFavorite;

                //ImagePath = imagePath;
                //Ingredients = new List<Ingredient>();
            }
        //add ratings
        public void AddRating(int rating)
        {
            ratings.Add(rating);
        }

        // Method to get average
        public double GetAverageRating()
        {
            if (ratings.Count == 0)
                return 0;
            return ratings.Average();
        }
        public void ScaleRecipe(int newServings)
        {
            foreach (Ingredient ingredient in this.Ingredients)
            {
              
                ingredient.Quantity *= newServings / this.quantity; 
            }
           
            this.quantity = newServings;
        }

    }
}
