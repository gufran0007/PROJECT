﻿namespace GroupProjectRecipeOrganizer
{
    partial class favourites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();

            btnCloseFavourites = new Button();

            button1 = new Button();

            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 20;
            listBox1.Location = new Point(236, 127);
            listBox1.Margin = new Padding(3, 4, 3, 4);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(451, 224);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // btnCloseFavourites
            // 
            btnCloseFavourites.Location = new Point(428, 455);
            btnCloseFavourites.Name = "btnCloseFavourites";
            btnCloseFavourites.Size = new Size(94, 29);
            btnCloseFavourites.TabIndex = 1;
            btnCloseFavourites.Text = "Close";
            btnCloseFavourites.UseVisualStyleBackColor = true;
            // button1
            // 
            button1.Location = new Point(272, 247);
            button1.Name = "button1";
            button1.Size = new Size(98, 23);
            button1.TabIndex = 1;
            button1.Text = "Close";
            button1.UseVisualStyleBackColor = true;
            //button1.Click += button1_Click;
            // 
            // favourites
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(btnCloseFavourites);
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "favourites";
            Text = "favourites";
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBox1;

        private Button btnCloseFavourites;

        private Button button1;

    }
}