﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class SearchByCategoryDialog : Form
    {
        public List<Recipe> recipes;
        public SearchByCategoryDialog(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            PopulateComboBox();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void PopulateComboBox()
        {
            // Populate the ComboBox with recipe categories
            comboBoxCategories.DataSource = Enum.GetValues(typeof(RecipeCategory));
        }

        private void btnSearchByCategoryClick_Click(object sender, EventArgs e)
        {
            // Get the selected category from the ComboBox
            RecipeCategory selectedCategory = (RecipeCategory)comboBoxCategories.SelectedItem;

            // Filter recipes based on the selected category
            List<Recipe> filteredRecipes = recipes.Where(r => r.Category == selectedCategory).ToList();

            // Show the search results in a message box
            if (filteredRecipes.Any())
            {
                StringBuilder message = new StringBuilder();
                message.AppendLine("Recipes found for the selected category:");
                foreach (Recipe recipe in filteredRecipes)
                {
                    message.AppendLine($"- {recipe.Name}");
                }
                MessageBox.Show(message.ToString(), "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No recipes found for the selected category.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSearchCategoryClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
