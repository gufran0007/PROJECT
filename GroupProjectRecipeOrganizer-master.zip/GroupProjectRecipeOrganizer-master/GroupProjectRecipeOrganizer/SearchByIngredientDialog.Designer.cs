﻿namespace GroupProjectRecipeOrganizer
{
    partial class SearchByIngredientDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSearchByIngredientClick = new Button();
            btnSearchByIngredientClose = new Button();
            cmbIngredients = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(145, 112);
            label1.Name = "label1";
            label1.Size = new Size(252, 38);
            label1.TabIndex = 0;
            label1.Text = "Enter a Ingredient:";
            // 
            // btnSearchByIngredientClick
            // 
            btnSearchByIngredientClick.Location = new Point(303, 229);
            btnSearchByIngredientClick.Name = "btnSearchByIngredientClick";
            btnSearchByIngredientClick.Size = new Size(164, 29);
            btnSearchByIngredientClick.TabIndex = 2;
            btnSearchByIngredientClick.Text = "Search By Ingredient";
            btnSearchByIngredientClick.UseVisualStyleBackColor = true;
            btnSearchByIngredientClick.Click += btnSearchByIngredientClick_Click;
            // 
            // btnSearchByIngredientClose
            // 
            btnSearchByIngredientClose.Location = new Point(337, 382);
            btnSearchByIngredientClose.Name = "btnSearchByIngredientClose";
            btnSearchByIngredientClose.Size = new Size(94, 29);
            btnSearchByIngredientClose.TabIndex = 3;
            btnSearchByIngredientClose.Text = "Close";
            btnSearchByIngredientClose.UseVisualStyleBackColor = true;
            btnSearchByIngredientClose.Click += btnSearchByIngredientClose_Click;
            // 
            // cmbIngredients
            // 
            cmbIngredients.FormattingEnabled = true;
            cmbIngredients.Location = new Point(421, 122);
            cmbIngredients.Name = "cmbIngredients";
            cmbIngredients.Size = new Size(151, 28);
            cmbIngredients.TabIndex = 4;
            // 
            // SearchByIngredientDialog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmbIngredients);
            Controls.Add(btnSearchByIngredientClose);
            Controls.Add(btnSearchByIngredientClick);
            Controls.Add(label1);
            Name = "SearchByIngredientDialog";
            Text = "SearchByIngredientDialog";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSearchByIngredientClick;
        private Button btnSearchByIngredientClose;
        private ComboBox cmbIngredients;
    }
}