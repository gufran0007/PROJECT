﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class SearchForm : Form
    {
        private List<Recipe> recipes;
        public SearchForm(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void btnSearchByName_Click(object sender, EventArgs e)
        {
            // Open the SearchByNameDialog
            SearchByNameDialog searchByNameDialog = new SearchByNameDialog(recipes);
            searchByNameDialog.ShowDialog();
        }

        private void btnSearchByCategory_Click(object sender, EventArgs e)
        {
            // Open the SearchByCategoryDialog
            SearchByCategoryDialog searchByCategoryDialog = new SearchByCategoryDialog(recipes);
            searchByCategoryDialog.ShowDialog();
        }

        private void btnSearchByIngredient_Click(object sender, EventArgs e)
        {
            // Open the SearchByIngredientDialog
            SearchByIngredientDialog searchByIngredientDialog = new SearchByIngredientDialog(recipes);
            searchByIngredientDialog.ShowDialog();
        }

        private void btnSearchClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
