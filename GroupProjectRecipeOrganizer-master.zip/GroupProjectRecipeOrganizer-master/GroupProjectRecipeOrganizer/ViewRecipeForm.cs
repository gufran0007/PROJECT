﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class ViewRecipeForm : Form
    {
        //List<Recipe> recipes = new List<Recipe>();
        public List<Recipe> recipes;
        public ViewRecipeForm(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            loadDataToList();
            DisplayRecipes();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void loadDataToList()
        {
            // Create Recipe objects and add ingredients
            Recipe r0 = new Recipe("Stew1", "Nice Stew1", RecipeCategory.Dinner, new List<Ingredient>(), "Preparation steps for stew 1", "notes", 2, true/*, "ImagePath1"*/);

            r0.Ingredients.Add(new Ingredient("Pink Salt", 1));
            r0.Ingredients.Add(new Ingredient("Pepper", 1));
            r0.Ingredients.Add(new Ingredient("Olive oil", 1));
            r0.Ingredients.Add(new Ingredient("Chicken stock or broth", 1));
            r0.Ingredients.Add(new Ingredient("Beef stock or broth", 1));
            r0.Ingredients.Add(new Ingredient("Canned tomatoes", 1));
            r0.Ingredients.Add(new Ingredient("Tomato sauce", 1));
            r0.Ingredients.Add(new Ingredient("Tomato paste", 1));
            r0.Ingredients.Add(new Ingredient("Onions", 1));
            r0.Ingredients.Add(new Ingredient("Garlic", 1));
            r0.Ingredients.Add(new Ingredient("Carrots", 1));
            r0.Ingredients.Add(new Ingredient("Celery", 1));
            r0.Ingredients.Add(new Ingredient("Potatoes", 1));
            r0.Ingredients.Add(new Ingredient("Thyme", 1));
            r0.Ingredients.Add(new Ingredient("Rosemary", 1));

            // Add the recipe to the list
            recipes.Add(r0);
        }

        private void DisplayRecipes()
        {
            // Clear existing rows
            dgvViewRecipeForm.Rows.Clear();

            // Add columns to the DataGridView
            dgvViewRecipeForm.Columns.Add("RecipeName", "Recipe Name");
            dgvViewRecipeForm.Columns.Add("RecipeDescription", "Description");
            dgvViewRecipeForm.Columns.Add("Category", "Category");
            dgvViewRecipeForm.Columns.Add("View", "View");
            dgvViewRecipeForm.Columns.Add("Modify", "Modify");
            dgvViewRecipeForm.Columns.Add("Delete", "Delete");

            // Populate DataGridView with recipe data
            foreach (Recipe recipe in recipes)
            {
                dgvViewRecipeForm.Rows.Add(recipe.Name, recipe.Description, recipe.Category, "View", "Modify", "Delete");
            }

            // Make header text bigger and bold
            dgvViewRecipeForm.ColumnHeadersDefaultCellStyle.Font = new Font(dgvViewRecipeForm.Font, FontStyle.Bold);
            dgvViewRecipeForm.ColumnHeadersDefaultCellStyle.Font = new Font(dgvViewRecipeForm.Font.FontFamily, 12, FontStyle.Bold);

            // Center header text
            foreach (DataGridViewColumn column in dgvViewRecipeForm.Columns)
            {
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

            // Customize button columns
            DataGridViewCellStyle buttonCellStyle = new DataGridViewCellStyle();
            buttonCellStyle.BackColor = Color.LightGreen;
            buttonCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvViewRecipeForm.Columns["View"].DefaultCellStyle = buttonCellStyle;
            dgvViewRecipeForm.Columns["Modify"].DefaultCellStyle = buttonCellStyle;
            dgvViewRecipeForm.Columns["Delete"].DefaultCellStyle = buttonCellStyle;

            // Set font for buttons
            Font buttonFont = new Font("Segoe", 10, FontStyle.Bold); 
            dgvViewRecipeForm.Columns["View"].DefaultCellStyle.Font = buttonFont;
            dgvViewRecipeForm.Columns["Modify"].DefaultCellStyle.Font = buttonFont;
            dgvViewRecipeForm.Columns["Delete"].DefaultCellStyle.Font = buttonFont;



            // Format DataGridView appearance
            dgvViewRecipeForm.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvViewRecipeForm.AllowUserToAddRows = false;
            dgvViewRecipeForm.AllowUserToDeleteRows = false;
            dgvViewRecipeForm.MultiSelect = false;
            dgvViewRecipeForm.ReadOnly = true;
            dgvViewRecipeForm.DefaultCellStyle.SelectionBackColor = SystemColors.Highlight;
            dgvViewRecipeForm.DefaultCellStyle.SelectionForeColor = SystemColors.HighlightText;
        }

        private void dgvViewRecipeForm_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            const int ViewIndex = 3; //View index
            const int ModifyIndex = 4; // Index of the "Modify" button column
            const int DeleteIndex = 5; // Index of the "Delete" button column


            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == ModifyIndex)
                {
                    ModifyRecipe(e.RowIndex);
                }
                else if (e.ColumnIndex == DeleteIndex)
                {
                    DeleteRecipe(e.RowIndex);
                }
                else if (e.ColumnIndex == ViewIndex)
                {
                    ViewRecipe(e.RowIndex);
                }
            }
        }

        private void ModifyRecipe(int rowIndex)
        {
            // Get the selected recipe
            Recipe selectedRecipe = recipes[rowIndex];

            // Open the EditRecipeForm
            EditRecipeForm editForm = new EditRecipeForm(ref selectedRecipe, selectedRecipe.Ingredients);

            // Show the form
            DialogResult editResult = editForm.ShowDialog();
            if (editResult == DialogResult.Yes)
            {
                // Update the recipe in the recipes list
                recipes[rowIndex] = selectedRecipe;

                // Update the display for the modified recipe only
                UpdateRecipeInDataGridView(selectedRecipe, rowIndex);
            }

        }

        private void UpdateRecipeInDataGridView(Recipe updatedRecipe, int rowIndex)
        {
            // Update the specific row in the DataGridView with the modified recipe
            dgvViewRecipeForm.Rows[rowIndex].Cells["RecipeName"].Value = updatedRecipe.Name;
            dgvViewRecipeForm.Rows[rowIndex].Cells["RecipeDescription"].Value = updatedRecipe.Description;
            dgvViewRecipeForm.Rows[rowIndex].Cells["Category"].Value = updatedRecipe.Category;
        }

        private void DeleteRecipe(int rowIndex)
        {
            // Confirm deletion
            DialogResult result = MessageBox.Show($"Are you sure you want to delete this recipe?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Remove the recipe from the list
                recipes.RemoveAt(rowIndex);

                // Remove the corresponding row from the DataGridView
                dgvViewRecipeForm.Rows.RemoveAt(rowIndex);

                // DisplayRecipes();

            }
        }


        //function to view recipe details
        private void ViewRecipe(int rowIndex)
        {
            try
            {
                Recipe selectedRecipe = recipes[rowIndex];
                Rcpdetailsform detailsForm = new Rcpdetailsform();
                detailsForm.ShowRecipeDetails(selectedRecipe);
                detailsForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnVRFClose_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close(); // Close the form
        }
    }

}
