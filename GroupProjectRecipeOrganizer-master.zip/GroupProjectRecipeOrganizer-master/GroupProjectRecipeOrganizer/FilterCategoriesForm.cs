﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class FilterCategoriesForm : Form
    {
        public FilterCategoriesForm()
        {
            InitializeComponent();
        }
    }
}
