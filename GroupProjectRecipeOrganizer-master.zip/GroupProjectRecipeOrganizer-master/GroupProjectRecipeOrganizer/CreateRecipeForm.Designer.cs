﻿namespace GroupProjectRecipeOrganizer
{
    partial class CreateRecipeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSave = new Button();
            btnCancel = new Button();
            label1 = new Label();
            txtName = new TextBox();
            label2 = new Label();
            txtDescription = new TextBox();
            label3 = new Label();
            cmbCategory = new ComboBox();
            label4 = new Label();
            txtPreparation = new TextBox();
            label5 = new Label();
            lstIngredients = new ListBox();
            btnAddIngredient = new Button();
            btnRemoveIngredient = new Button();
            label6 = new Label();
            label8 = new Label();
            numQuantity = new NumericUpDown();
            cmbIngredient = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)numQuantity).BeginInit();
            SuspendLayout();
            // 
            // btnSave
            // 
            btnSave.Location = new Point(132, 828);
            btnSave.Margin = new Padding(5, 6, 5, 6);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(113, 40);
            btnSave.TabIndex = 0;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSaveCreate_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(391, 828);
            btnCancel.Margin = new Padding(5, 6, 5, 6);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(113, 40);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancelCreate_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(52, 53);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(66, 28);
            label1.TabIndex = 2;
            label1.Text = "Name";
            // 
            // txtName
            // 
            txtName.Location = new Point(204, 48);
            txtName.Margin = new Padding(5, 6, 5, 6);
            txtName.Name = "txtName";
            txtName.Size = new Size(355, 30);
            txtName.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(52, 124);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(115, 28);
            label2.TabIndex = 4;
            label2.Text = "Description";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(204, 118);
            txtDescription.Margin = new Padding(5, 6, 5, 6);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(355, 96);
            txtDescription.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(52, 256);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(94, 28);
            label3.TabIndex = 6;
            label3.Text = "Category";
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Location = new Point(204, 251);
            cmbCategory.Margin = new Padding(5, 6, 5, 6);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(355, 31);
            cmbCategory.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(52, 331);
            label4.Margin = new Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new Size(117, 28);
            label4.TabIndex = 8;
            label4.Text = "Preparation";
            // 
            // txtPreparation
            // 
            txtPreparation.Location = new Point(204, 325);
            txtPreparation.Margin = new Padding(5, 6, 5, 6);
            txtPreparation.Multiline = true;
            txtPreparation.Name = "txtPreparation";
            txtPreparation.Size = new Size(355, 96);
            txtPreparation.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(52, 505);
            label5.Margin = new Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new Size(116, 28);
            label5.TabIndex = 10;
            label5.Text = "Ingredients";
            // 
            // lstIngredients
            // 
            lstIngredients.FormattingEnabled = true;
            lstIngredients.ItemHeight = 23;
            lstIngredients.Location = new Point(204, 505);
            lstIngredients.Margin = new Padding(5, 6, 5, 6);
            lstIngredients.Name = "lstIngredients";
            lstIngredients.Size = new Size(355, 188);
            lstIngredients.TabIndex = 11;
            // 
            // btnAddIngredient
            // 
            btnAddIngredient.Location = new Point(449, 757);
            btnAddIngredient.Margin = new Padding(5, 6, 5, 6);
            btnAddIngredient.Name = "btnAddIngredient";
            btnAddIngredient.Size = new Size(113, 40);
            btnAddIngredient.TabIndex = 12;
            btnAddIngredient.Text = "Add";
            btnAddIngredient.UseVisualStyleBackColor = true;
            btnAddIngredient.Click += btnAddIngredient_Click;
            // 
            // btnRemoveIngredient
            // 
            btnRemoveIngredient.Location = new Point(449, 705);
            btnRemoveIngredient.Margin = new Padding(5, 6, 5, 6);
            btnRemoveIngredient.Name = "btnRemoveIngredient";
            btnRemoveIngredient.Size = new Size(113, 40);
            btnRemoveIngredient.TabIndex = 13;
            btnRemoveIngredient.Text = "Remove";
            btnRemoveIngredient.UseVisualStyleBackColor = true;
            btnRemoveIngredient.Click += btnRemoveIngredient_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(52, 722);
            label6.Margin = new Padding(5, 0, 5, 0);
            label6.Name = "label6";
            label6.Size = new Size(107, 28);
            label6.TabIndex = 14;
            label6.Text = "Ingredient";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(52, 446);
            label8.Margin = new Padding(5, 0, 5, 0);
            label8.Name = "label8";
            label8.Size = new Size(90, 28);
            label8.TabIndex = 18;
            label8.Text = "Quantity";
            // 
            // numQuantity
            // 
            numQuantity.Location = new Point(204, 443);
            numQuantity.Margin = new Padding(5, 6, 5, 6);
            numQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numQuantity.Name = "numQuantity";
            numQuantity.Size = new Size(90, 30);
            numQuantity.TabIndex = 19;
            numQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // cmbIngredient
            // 
            cmbIngredient.FormattingEnabled = true;
            cmbIngredient.Location = new Point(204, 722);
            cmbIngredient.Name = "cmbIngredient";
            cmbIngredient.Size = new Size(169, 31);
            cmbIngredient.TabIndex = 20;
            // 
            // CreateRecipeForm
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(594, 867);
            Controls.Add(cmbIngredient);
            Controls.Add(numQuantity);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(btnRemoveIngredient);
            Controls.Add(btnAddIngredient);
            Controls.Add(lstIngredients);
            Controls.Add(label5);
            Controls.Add(txtPreparation);
            Controls.Add(label4);
            Controls.Add(cmbCategory);
            Controls.Add(label3);
            Controls.Add(txtDescription);
            Controls.Add(label2);
            Controls.Add(txtName);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(5, 6, 5, 6);
            Name = "CreateRecipeForm";
            Text = "Create Recipe";
            Load += CreateRecipeForm_Load;
            ((System.ComponentModel.ISupportInitialize)numQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPreparation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstIngredients;
        private System.Windows.Forms.Button btnAddIngredient;
        private System.Windows.Forms.Button btnRemoveIngredient;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numQuantity;
        private ComboBox cmbIngredient;
    }
}