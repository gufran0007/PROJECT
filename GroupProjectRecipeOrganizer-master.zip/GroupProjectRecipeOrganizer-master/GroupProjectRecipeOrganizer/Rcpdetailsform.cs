﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class Rcpdetailsform : Form
    {
        public Rcpdetailsform()
        {
            InitializeComponent();

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Rcpdetailsform_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private Recipe currentRecipe;
        public void ShowRecipeDetails(Recipe recipe)
        {
            currentRecipe = recipe;
            // Update the labels and textboxes with the recipe details
            label1.Text = recipe.Name;
            label2.Text = recipe.Description;
            label3.Text = recipe.Category.ToString();
            //label4.Text = recipe.quantity.ToString();//not need just fir scaling 
            textBox1.Text = recipe.Preparation;

            // Display ingredients in the list box
            Ingredients.Items.Clear();
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                Ingredients.Items.Add($"{ingredient.Quantity}x {ingredient.IngredientName}");

            }
        }

        private void addnote_Click(object sender, EventArgs e)
        {
            string note = Microsoft.VisualBasic.Interaction.InputBox("Enter your note for this recipe:", "Add Note", currentRecipe.Notes);

            // Check if note was not empty or the user didn't cancel the input
            if (!string.IsNullOrEmpty(note))
            {
                // Save the note to the current recipe
                currentRecipe.Notes = note;
            }
        }

        private void seenote_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentRecipe.Notes))
            {
                // Show the note
                MessageBox.Show(currentRecipe.Notes, "Recipe Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Inform the user that there is no note
                MessageBox.Show("There is no note for this recipe.", "No Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void addtofavourites_Click(object sender, EventArgs e)
        {
            if (currentRecipe != null)
            {
                currentRecipe.IsFavorite = true;
                MessageBox.Show($"{currentRecipe.Name} has been added to your favorites!", "Added to Favorites", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Rate_Click(object sender, EventArgs e)
        {
            if (currentRecipe != null)
            {
                // Replace with your preferred way of obtaining a rating, for example using a Rating Control or another form/dialog
                var ratingInput = Microsoft.VisualBasic.Interaction.InputBox("Enter your rating for this recipe (1-5):", "Rate Recipe", "5");

                if (int.TryParse(ratingInput, out int rating) && rating >= 1 && rating <= 5)
                {
                    currentRecipe.AddRating(rating);
                    MessageBox.Show("Thank you for rating this recipe!", "Rating Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please enter a valid rating between 1 and 5.", "Invalid Rating", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void ratings_Click(object sender, EventArgs e)
        {
            if (currentRecipe != null)
            {
                double averageRating = currentRecipe.GetAverageRating();
                MessageBox.Show($"The average rating for {currentRecipe.Name} is {averageRating:F1}/5", "Average Rating", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Scalerecipe_Click(object sender, EventArgs e)
        {

            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the number of servings:", "Scale Recipe", currentRecipe.quantity.ToString());

            if (int.TryParse(input, out int newServings) && newServings > 0)
            {
                currentRecipe.ScaleRecipe(newServings);


                Ingredients.Items.Clear();
                foreach (Ingredient ingredient in currentRecipe.Ingredients)
                {
                    Ingredients.Items.Add($"{ingredient.Quantity}x {ingredient.IngredientName}");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number of servings.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

