namespace GroupProjectRecipeOrganizer
{
    public partial class RecipeOrganizer : Form
    {
        public List<Recipe> recipes = new List<Recipe>();
        private List<Recipe> favoriteRecipes;




        public RecipeOrganizer()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
            favoriteRecipes = new List<Recipe>();



            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void UpdateFavorites()
        {
            favoriteRecipes = recipes.Where(r => r.IsFavorite).ToList();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRecipes_Click(object sender, EventArgs e)
        {
            ViewRecipeForm viewRecipeForm = new ViewRecipeForm(recipes);
            viewRecipeForm.ShowDialog();
        }


        private void loadDataToList()
        {
            // Create Recipe objects and add ingredients
            Recipe r0 = new Recipe("Stew1", "Nice Stew1", RecipeCategory.Dinner, new List<Ingredient>(), "Preparation steps for stew 1", "notes", 2, true/*, "ImagePath1"*/);

            r0.Ingredients.Add(new Ingredient("Pink Salt", 1));
            r0.Ingredients.Add(new Ingredient("Pepper", 1));
            r0.Ingredients.Add(new Ingredient("Olive oil", 1));
            r0.Ingredients.Add(new Ingredient("Chicken stock or broth", 1));
            r0.Ingredients.Add(new Ingredient("Beef stock or broth", 1));
            r0.Ingredients.Add(new Ingredient("Canned tomatoes", 1));
            r0.Ingredients.Add(new Ingredient("Tomato sauce", 1));
            r0.Ingredients.Add(new Ingredient("Tomato paste", 1));
            r0.Ingredients.Add(new Ingredient("Onions", 1));
            r0.Ingredients.Add(new Ingredient("Garlic", 1));
            r0.Ingredients.Add(new Ingredient("Carrots", 1));
            r0.Ingredients.Add(new Ingredient("Celery", 1));
            r0.Ingredients.Add(new Ingredient("Potatoes", 1));
            r0.Ingredients.Add(new Ingredient("Thyme", 1));
            r0.Ingredients.Add(new Ingredient("Rosemary", 1));

            // Add the recipe to the list
            recipes.Add(r0);
        }


        private void btnCREATE_Click(object sender, EventArgs e)
        {
            CreateRecipeForm createForm = new CreateRecipeForm(recipes);

            // Show the form modally
            DialogResult result = createForm.ShowDialog();

            // Check if the user clicked the Save button
            if (result == DialogResult.OK)
            {
                // Recipe was created successfully
                //DisplayRecipes();
            }

        }
        public static class FavoriteRecipesStorage
        {
            public static List<Recipe> Favorites { get; } = new List<Recipe>();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateFavorites();
            FavouritesForm favoritesForm = new FavouritesForm(favoriteRecipes);
            favoritesForm.ShowDialog();
        }

        private void RecipeOrganizer_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchForm searchForm = new SearchForm(recipes);
            searchForm.ShowDialog();
        }






    }

}