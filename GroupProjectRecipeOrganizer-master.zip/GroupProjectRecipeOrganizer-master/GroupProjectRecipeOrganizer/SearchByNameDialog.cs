﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectRecipeOrganizer
{
    public partial class SearchByNameDialog : Form
    {
        public List<Recipe> recipes;
        public SearchByNameDialog(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            this.BackgroundImage = Properties.Resources.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void btnSearchByNameClick_Click(object sender, EventArgs e)
        {
            // Get the search query from the textbox
            string searchQuery = txtSearchRecipeName.Text.Trim();

            // Check if the search query is empty
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                MessageBox.Show("Please enter a recipe name to search.", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the recipes list is initialized
            if (recipes != null)
            {
                // Filter the recipes by name
                var searchResults = recipes.Where(recipe => recipe.Name.ToLower().Contains(searchQuery.ToLower())).ToList();

                // Check if any recipes match the search query
                if (searchResults.Any())
                {
                    // Display search results in a MessageBox or any other way you prefer
                    StringBuilder resultMessage = new StringBuilder();
                    resultMessage.AppendLine("Search Results:");
                    foreach (var recipe in searchResults)
                    {
                        resultMessage.AppendLine($"Name: {recipe.Name}, Description: {recipe.Description}");
                    }
                    MessageBox.Show(resultMessage.ToString(), "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No recipes found matching the search criteria.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Recipe list is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnCloseSearchByName_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
